<?php

namespace iutnc\touiteur\db;


class User
{
    private $id;
    private $email;
    private $passwd;
    private $role;




}
